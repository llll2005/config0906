local x = 10

if x > 3 then
  x = 3
elseif x < 3 then
  x = -3
else
  if x > 0 then
    x = 1
  end
  x = 0
end

if x > 2 then
