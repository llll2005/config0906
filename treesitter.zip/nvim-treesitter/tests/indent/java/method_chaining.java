public class Foo {
  void foo() {
    new StringBuilder()
      .append("a")
  }
}
