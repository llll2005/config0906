fn foo() -> i32 {
    if let Some(v) = Some(2) {
        1
    } else {
        2
    }
}
