require('Comment').setup()
