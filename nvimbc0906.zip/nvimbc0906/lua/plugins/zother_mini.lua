return {
  "echasnovski/mini.nvim",
}
