return{
  "junegunn/goyo.vim", -- 文檔置中
  -- config = {},
}
