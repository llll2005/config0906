--File: .config/nvim/lua/plugins/zdebugger_dap-ui.lua
--Project: L_in_arch
--Creation date: Fri 05 Jul 2024 11:39:28 PM CST
--Author: llll2005 <f20050510@gmail.com>
-------
--Last modified: Fri 05 Jul 2024 11:39:37 PM CST
--Modified By: llll2005
-------
return {
  "rcarriga/nvim-dap-ui",
  dependencies = {"mfussenegger/nvim-dap", "nvim-neotest/nvim-nio"},
  config = {
    
  },
}
